# module mane: main
import read
import purchase
import write

again = "Y"
while again.upper() == "Y":
    a = read.read_file()
    b = purchase.purchase(a)
    write.over_write(a, b)
    again = input("\nAda barang lain yang akan dipinjam?(Y/N) ")
print("\nTerima kasih untuk menunggu!!")
print("Cek kembali barang yang anda pinjam sesuai RECEIPT, \nWhich we have created in .txt file format.")
