file = open("tes.txt", "w")  # generate a unique invoive name and open it in write mode.
    file.write("=============================================================")
    file.close()
    return q